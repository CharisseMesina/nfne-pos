﻿namespace pos_01
{
    partial class loginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(loginForm));
            this.mainPanel = new System.Windows.Forms.Panel();
            this.infoPanel = new System.Windows.Forms.Panel();
            this.loginPanel = new System.Windows.Forms.Panel();
            this.idNumTB = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.pwTB = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.loginB = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lbl1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.navPanel = new System.Windows.Forms.Panel();
            this.minB = new Bunifu.Framework.UI.BunifuImageButton();
            this.exitB = new Bunifu.Framework.UI.BunifuImageButton();
            this.mainPanel.SuspendLayout();
            this.loginPanel.SuspendLayout();
            this.navPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.minB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.exitB)).BeginInit();
            this.SuspendLayout();
            // 
            // mainPanel
            // 
            this.mainPanel.Controls.Add(this.infoPanel);
            this.mainPanel.Controls.Add(this.loginPanel);
            this.mainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainPanel.Location = new System.Drawing.Point(0, 0);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(960, 720);
            this.mainPanel.TabIndex = 0;
            // 
            // infoPanel
            // 
            this.infoPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(63)))), ((int)(((byte)(80)))));
            this.infoPanel.BackgroundImage = global::pos_01.Properties.Resources.banner_02;
            this.infoPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.infoPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.infoPanel.ForeColor = System.Drawing.Color.White;
            this.infoPanel.Location = new System.Drawing.Point(0, 0);
            this.infoPanel.Name = "infoPanel";
            this.infoPanel.Size = new System.Drawing.Size(560, 720);
            this.infoPanel.TabIndex = 1;
            // 
            // loginPanel
            // 
            this.loginPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(188)))), ((int)(((byte)(155)))));
            this.loginPanel.Controls.Add(this.idNumTB);
            this.loginPanel.Controls.Add(this.pwTB);
            this.loginPanel.Controls.Add(this.loginB);
            this.loginPanel.Controls.Add(this.bunifuCustomLabel1);
            this.loginPanel.Controls.Add(this.bunifuCustomLabel2);
            this.loginPanel.Controls.Add(this.lbl1);
            this.loginPanel.Controls.Add(this.navPanel);
            this.loginPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.loginPanel.ForeColor = System.Drawing.Color.White;
            this.loginPanel.Location = new System.Drawing.Point(560, 0);
            this.loginPanel.Name = "loginPanel";
            this.loginPanel.Size = new System.Drawing.Size(400, 720);
            this.loginPanel.TabIndex = 0;
            // 
            // idNumTB
            // 
            this.idNumTB.BorderColorFocused = System.Drawing.Color.White;
            this.idNumTB.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.idNumTB.BorderColorMouseHover = System.Drawing.Color.White;
            this.idNumTB.BorderThickness = 3;
            this.idNumTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.idNumTB.Font = new System.Drawing.Font("Gotham", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idNumTB.ForeColor = System.Drawing.Color.White;
            this.idNumTB.isPassword = false;
            this.idNumTB.Location = new System.Drawing.Point(38, 155);
            this.idNumTB.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.idNumTB.Name = "idNumTB";
            this.idNumTB.Size = new System.Drawing.Size(321, 55);
            this.idNumTB.TabIndex = 8;
            this.idNumTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // pwTB
            // 
            this.pwTB.BorderColorFocused = System.Drawing.Color.White;
            this.pwTB.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pwTB.BorderColorMouseHover = System.Drawing.Color.White;
            this.pwTB.BorderThickness = 3;
            this.pwTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.pwTB.Font = new System.Drawing.Font("Gotham", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pwTB.ForeColor = System.Drawing.Color.White;
            this.pwTB.isPassword = true;
            this.pwTB.Location = new System.Drawing.Point(38, 255);
            this.pwTB.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.pwTB.Name = "pwTB";
            this.pwTB.Size = new System.Drawing.Size(321, 55);
            this.pwTB.TabIndex = 7;
            this.pwTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // loginB
            // 
            this.loginB.Activecolor = System.Drawing.Color.Silver;
            this.loginB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(63)))), ((int)(((byte)(80)))));
            this.loginB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.loginB.BorderRadius = 0;
            this.loginB.ButtonText = "LOGIN";
            this.loginB.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginB.DisabledColor = System.Drawing.Color.Gray;
            this.loginB.Iconcolor = System.Drawing.Color.Transparent;
            this.loginB.Iconimage = null;
            this.loginB.Iconimage_right = null;
            this.loginB.Iconimage_right_Selected = null;
            this.loginB.Iconimage_Selected = null;
            this.loginB.IconMarginLeft = 0;
            this.loginB.IconMarginRight = 0;
            this.loginB.IconRightVisible = true;
            this.loginB.IconRightZoom = 0D;
            this.loginB.IconVisible = true;
            this.loginB.IconZoom = 90D;
            this.loginB.IsTab = false;
            this.loginB.Location = new System.Drawing.Point(98, 344);
            this.loginB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.loginB.Name = "loginB";
            this.loginB.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(63)))), ((int)(((byte)(80)))));
            this.loginB.OnHovercolor = System.Drawing.Color.White;
            this.loginB.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(63)))), ((int)(((byte)(80)))));
            this.loginB.selected = false;
            this.loginB.Size = new System.Drawing.Size(205, 52);
            this.loginB.TabIndex = 6;
            this.loginB.Text = "LOGIN";
            this.loginB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.loginB.Textcolor = System.Drawing.Color.White;
            this.loginB.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginB.Click += new System.EventHandler(this.loginB_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Gotham", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(35, 233);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(89, 17);
            this.bunifuCustomLabel1.TabIndex = 4;
            this.bunifuCustomLabel1.Text = "Password:";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Gotham", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.Image = global::pos_01.Properties.Resources.logo_2;
            this.bunifuCustomLabel2.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(10, 75);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(378, 34);
            this.bunifuCustomLabel2.TabIndex = 3;
            this.bunifuCustomLabel2.Text = "LOGIN";
            this.bunifuCustomLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Gotham", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(35, 133);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(112, 17);
            this.lbl1.TabIndex = 1;
            this.lbl1.Text = "Employee ID:";
            // 
            // navPanel
            // 
            this.navPanel.BackColor = System.Drawing.Color.Transparent;
            this.navPanel.Controls.Add(this.minB);
            this.navPanel.Controls.Add(this.exitB);
            this.navPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.navPanel.Location = new System.Drawing.Point(0, 0);
            this.navPanel.Name = "navPanel";
            this.navPanel.Size = new System.Drawing.Size(400, 50);
            this.navPanel.TabIndex = 0;
            // 
            // minB
            // 
            this.minB.BackColor = System.Drawing.Color.Transparent;
            this.minB.Image = global::pos_01.Properties.Resources.minimize_02;
            this.minB.ImageActive = null;
            this.minB.Location = new System.Drawing.Point(322, 12);
            this.minB.Name = "minB";
            this.minB.Size = new System.Drawing.Size(30, 30);
            this.minB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.minB.TabIndex = 2;
            this.minB.TabStop = false;
            this.minB.Zoom = 10;
            this.minB.Click += new System.EventHandler(this.minB_Click);
            // 
            // exitB
            // 
            this.exitB.BackColor = System.Drawing.Color.Transparent;
            this.exitB.Image = global::pos_01.Properties.Resources.close_02;
            this.exitB.ImageActive = global::pos_01.Properties.Resources.close_03;
            this.exitB.InitialImage = null;
            this.exitB.Location = new System.Drawing.Point(358, 12);
            this.exitB.Name = "exitB";
            this.exitB.Size = new System.Drawing.Size(30, 30);
            this.exitB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.exitB.TabIndex = 1;
            this.exitB.TabStop = false;
            this.exitB.Zoom = 10;
            this.exitB.Click += new System.EventHandler(this.exitB_Click);
            // 
            // loginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(960, 720);
            this.Controls.Add(this.mainPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "loginForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NFNE";
            this.mainPanel.ResumeLayout(false);
            this.loginPanel.ResumeLayout(false);
            this.loginPanel.PerformLayout();
            this.navPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.minB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.exitB)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Panel loginPanel;
        private System.Windows.Forms.Panel infoPanel;
        private System.Windows.Forms.Panel navPanel;
        private Bunifu.Framework.UI.BunifuImageButton exitB;
        private Bunifu.Framework.UI.BunifuImageButton minB;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuFlatButton loginB;
        private Bunifu.Framework.UI.BunifuMetroTextbox idNumTB;
        private Bunifu.Framework.UI.BunifuMetroTextbox pwTB;

    }
}

