﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Validation;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pos_01
{
    public partial class employeeListForm : Form
    {


        private static List<ttype> getListTypes;
       
        public employeeListForm()
        {
            InitializeComponent();
            
        }

        List<ttype> getType()
        {
            var getrecords = (from c in ContextObject.context.ttypes.OfType<ttype>() select c).ToList();
            return getrecords;
        }

        private void exitB_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void minB_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        void getEmployee()
        {
            var getrecord = (from c in ContextObject.context.temployees.OfType<temployee>()
                             select new
                             {
                                 Employee_ID= c.empID,
                                 First_Name = c.empFNAME,
                                 Last_Name = c.empLNAME,
                                 Address = c.empADD,
                                 Contact_Number = c.empCONTACT,
                                 Date_of_Birth = c.empDOB,
                                 User_Type = c.ttype.empTYPENAME
                             }).ToList();
           
            bunifuCustomDataGrid1.DataSource= getrecord;
        }

        private void employeeListForm_Load(object sender, EventArgs e)
        {
          getEmployee();
          getListTypes = getType();
        }

        private static int cellSelected;

        private void bunifuCustomDataGrid1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cellSelected = Convert.ToInt32(bunifuCustomDataGrid1.Rows[e.RowIndex].Cells[0].Value);
            var getrecord = (from c in ContextObject.context.temployees.OfType<temployee>()
                             where c.empID == cellSelected
                             select c).First();
            bunifuMetroTextbox2.Text = getrecord.empFNAME;
            bunifuMetroTextbox3.Text = getrecord.empLNAME;
            bunifuCustomTextbox1.Text = getrecord.empADD;
            bunifuMetroTextbox7.Text = getrecord.empCONTACT;
            bunifuMetroTextbox4.Text = getrecord.empDOB;
            bunifuMetroTextbox5.Text = Convert.ToString(getrecord.empID);
            bunifuMetroTextbox6.Text = getrecord.empPASS;
            if (getrecord.ttype.empTYPEID == 1)
            {
                radioButton1.Checked = true;
                radioButton2.Checked = false;
                radioButton3.Checked = false;
            }
            else if (getrecord.ttype.empTYPEID == 2)
            {
                radioButton2.Checked = true;
                radioButton1.Checked = false;
                radioButton3.Checked = false;

            }
            else if (getrecord.ttype.empTYPEID == 3)
            {
                radioButton3.Checked = true;
                radioButton2.Checked = false;
                radioButton1.Checked = false;

            }
          
            

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            temployee add = new temployee();
            add.ttype = new ttype();
            add.empFNAME = bunifuMetroTextbox2.Text;
            add.empLNAME = bunifuMetroTextbox3.Text;
            add.empADD = bunifuCustomTextbox1.Text;
            add.empCONTACT = bunifuMetroTextbox7.Text;
            add.empDOB = bunifuMetroTextbox4.Text;
            add.empID = int.Parse(bunifuMetroTextbox5.Text);
            add.empPASS = bunifuMetroTextbox6.Text;
            
            if (radioButton1.Checked)
            {

                add.ttype = getListTypes[0] as ttype;
            }
            else if (radioButton2.Checked)
            {
                add.ttype = getListTypes[1] as ttype;
            }
            else if (radioButton3.Checked)
            {

                add.ttype = getListTypes[2] as ttype;
            }

           
            ContextObject.context.temployees.Add(add);
            try
            {
                ContextObject.context.SaveChanges();
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var entityValidationErrors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in entityValidationErrors.ValidationErrors)
                    {
                        Console.Write("Property: " + validationError.PropertyName + "Error: " + validationError.ErrorMessage);
                    }
                }
            }
         
            
            getEmployee();
        }
      


    
        private void bunifuFlatButton7_Click(object sender, EventArgs e)
        {
            var getrecords = (from c in ContextObject.context.temployees.OfType<temployee>()
                              where c.empID == cellSelected
                              select c).First();
            getrecords.empFNAME = bunifuMetroTextbox2.Text;
            getrecords.empLNAME = bunifuMetroTextbox3.Text;
            getrecords.empADD = bunifuCustomTextbox1.Text;
            getrecords.empCONTACT = bunifuMetroTextbox7.Text;
            getrecords.empDOB = bunifuMetroTextbox4.Text;
            getrecords.empPASS = bunifuMetroTextbox6.Text;
            if (radioButton1.Checked)
            {
                getrecords.ttype = getListTypes[0] as ttype;
            }
            else if (radioButton2.Checked)
            {
                getrecords.ttype = getListTypes[1] as ttype;
            }
            else if (radioButton3.Checked)
            {
                getrecords.ttype = getListTypes[2] as ttype;
            }

            ContextObject.context.SaveChanges();
            getEmployee();
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            bunifuMetroTextbox2.Text = "";
            bunifuMetroTextbox3.Text = "";
            bunifuCustomTextbox1.Text = "";
            bunifuMetroTextbox7.Text = "";
            bunifuMetroTextbox4.Text = "";
            bunifuMetroTextbox5.Text = "";
            bunifuMetroTextbox6.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
        }

        private void bunifuFlatButton6_Click(object sender, EventArgs e)
        {
            var getrecords = (from c in ContextObject.context.temployees.OfType<temployee>()
                              where c.empID == cellSelected
                              select c).First();
            ContextObject.context.temployees.Remove(getrecords);
            ContextObject.context.SaveChanges();
            getEmployee();
        }

        private void bunifuMetroTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            var getrecords = (from c in ContextObject.context.temployees.OfType<temployee>()
                              where c.empID == Convert.ToInt32(bunifuMetroTextbox1.Text) ||
                              c.empFNAME == bunifuMetroTextbox1.Text ||
                               c.empLNAME == bunifuMetroTextbox1.Text ||
                               c.empADD == bunifuMetroTextbox1.Text ||
                               c.ttype.empTYPENAME == bunifuMetroTextbox1.Text ||
                              c.empFNAME.Contains(bunifuMetroTextbox1.Text) ||
                              c.empLNAME.Contains(bunifuMetroTextbox1.Text) ||
                              c.empADD.Contains(bunifuMetroTextbox1.Text) ||
                              c.ttype.empTYPENAME.Contains(bunifuMetroTextbox1.Text)
                              select c).ToList();

            bunifuCustomDataGrid1.DataSource = getrecords;
        }

        private void bunifuMetroTextbox2_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuCustomDataGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bunifuCustomDataGrid1_Paint(object sender, PaintEventArgs e)
        {
            foreach (DataGridViewColumn c in bunifuCustomDataGrid1.Columns)
            {
                c.HeaderText = c.HeaderText.Replace("_", " ");

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dateandtime = DateTime.Now;
            this.label2.Text = dateandtime.ToString("hh:mm:ss");
            this.label1.Text = dateandtime.ToString("MM-dd-yyy");

        }

        private void label1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

     


       
    }
}
