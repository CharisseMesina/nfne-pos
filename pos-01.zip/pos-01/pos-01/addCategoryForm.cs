﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Validation;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pos_01
{
    public partial class addCategoryForm : Form
    {
        public addCategoryForm()
        {
            InitializeComponent();
        }
        private void timer1_Tick(object sender, EventArgs e) 
        {
            DateTime dateandtime = DateTime.Now;
           this.label2.Text = dateandtime.ToString("hh:mm:ss");
             this.label1.Text = dateandtime.ToString("MM-dd-yyy");

        }

        private void label1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void minB_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        void gettable()
        {
            var getrecord = (from c in ContextObject.context.tcategories.OfType<tcategory>()
                             select new
                             {
                                 Category_ID = c.catID,
                                 Category_Name = c.catNAME
                                 
                             }).ToList();

            bunifuCustomDataGrid1.DataSource = getrecord;
        }
        private void exitB_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bunifuCustomDataGrid1_Paint(object sender, PaintEventArgs e)
        {
            foreach (DataGridViewColumn c in bunifuCustomDataGrid1.Columns)
            {
                c.HeaderText = c.HeaderText.Replace("_", " ");

            }
        }

        private void addCategoryForm_Load(object sender, EventArgs e)
        {
            gettable();
        }
        public static int cellSelected;
        private void bunifuCustomDataGrid1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cellSelected = Convert.ToInt32(bunifuCustomDataGrid1.Rows[e.RowIndex].Cells[0].Value);
            var getrecords = (from c in ContextObject.context.tcategories.OfType<tcategory>()
                              where c.catID == cellSelected
                              select c).First();
            bunifuMetroTextbox2.Text = getrecords.catNAME;
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            tcategory add = new tcategory();
            add.catNAME = bunifuMetroTextbox2.Text;
            ContextObject.context.tcategories.Add(add);
            try
            {
                ContextObject.context.SaveChanges();
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var entityValidationErrors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in entityValidationErrors.ValidationErrors)
                    {
                        Console.Write("Property: " + validationError.PropertyName + "Error: " + validationError.ErrorMessage);
                    }
                }
            }
            gettable();
        }

       

    }
}
