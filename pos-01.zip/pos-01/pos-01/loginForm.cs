﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pos_01
{
    public partial class loginForm : Form
    {
        public loginForm()
        {
            InitializeComponent();
        }

        private void loginB_Click(object sender, EventArgs e)
        {
         
            if(validate(idNumTB.Text, pwTB.Text)){
                MessageBox.Show("You are logged in successfully!");
                homeForm hf = new homeForm(idNumTB.Text);
                
                hf.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Login Error!");
                idNumTB.Text="";
                pwTB.Text="";
            }
        }

        public bool validate(string uname, string pass)
        {
            var record = (from c in ContextObject.context.temployees.OfType<temployee>()
                          where Convert.ToString(c.empID) == idNumTB.Text ||
                          c.empPASS == pwTB.Text
                          select c);
            if (record!=null)
            {
                return true;
            }
            else
            {
               return false;
            }
        }

        

        private void exitB_Click(object sender, EventArgs e)
        {
            Dispose();
            System.Environment.Exit(1);
        }

        private void minB_Click(object sender, EventArgs e)
        {

            this.WindowState = FormWindowState.Minimized;
        }
    }
}
