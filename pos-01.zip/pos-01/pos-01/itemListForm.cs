﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Validation;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pos_01
{
    public partial class itemListForm : Form
    {
        private static List<tcategory> getListCat;

        public itemListForm()
        {
            InitializeComponent();
        }

        List<tcategory> getCat()
        {
            var getrecords = (from c in ContextObject.context.tcategories.OfType<tcategory>() select c).ToList();
            return getrecords;
        }

        void getInventory()
        {
            var getrecord = (from c in ContextObject.context.tinventories.OfType<tinventory>()
                             select new
                             {
                                 Item_Code = c.ITEM_CODE,
                                 Item_Name = c.ITEM_NAME,
                                 On_Stock = c.ONSTOCK,
                                 Purchase_Price = c.PURCHASE_PRICE,
                                 Sales_Price = c.SALES_PRICE,
                                 Supplier = c.SUPPLIER,
                                 Category = c.tcategory.catNAME,
                                 Expiry_Date = c.EXPIRY_DATE
                             }).ToList();
            bunifuCustomDataGrid1.DataSource = getrecord;
        }
        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            bunifuMetroTextbox2.Text = "";
            bunifuMetroTextbox3.Text = "";
            bunifuMetroTextbox7.Text = "";
            bunifuMetroTextbox4.Text = "";
            bunifuMetroTextbox5.Text = "";
            bunifuMetroTextbox6.Text = "";
            bunifuMetroTextbox9.Text = "";
        }

        private static String combovalue;

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            tinventory add = new tinventory();
            add.ITEM_CODE = int.Parse(bunifuMetroTextbox2.Text);
            add.ITEM_NAME = bunifuMetroTextbox3.Text;
            add.ONSTOCK = bunifuMetroTextbox7.Text;
            add.PURCHASE_PRICE = bunifuMetroTextbox4.Text;
            add.SALES_PRICE = bunifuMetroTextbox5.Text;
            add.SUPPLIER = bunifuMetroTextbox6.Text;
            add.EXPIRY_DATE = bunifuMetroTextbox9.Text;
            add.tcategory = getListCat[Convert.ToInt32(combovalue)] as tcategory;

            ContextObject.context.tinventories.Add(add);
            try
            {
                ContextObject.context.SaveChanges();
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var entityValidationErrors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in entityValidationErrors.ValidationErrors)
                    {
                        Console.Write("Property: " + validationError.PropertyName + "Error: " + validationError.ErrorMessage);
                    }
                }
            }
            getInventory();
        }
        private static int cellSelected;
        private void bunifuCustomDataGrid1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cellSelected = Convert.ToInt32(bunifuCustomDataGrid1.Rows[e.RowIndex].Cells[0].Value);
            var getrecord = (from c in ContextObject.context.tinventories.OfType<tinventory>()
                             where c.ITEM_CODE == cellSelected
                             select c).First();
            bunifuMetroTextbox2.Text = Convert.ToString(getrecord.ITEM_CODE); 
            bunifuMetroTextbox3.Text = getrecord.ITEM_NAME;
            bunifuMetroTextbox7.Text = getrecord.ONSTOCK;
            bunifuMetroTextbox4.Text = getrecord.PURCHASE_PRICE;
            bunifuMetroTextbox5.Text = getrecord.SALES_PRICE;
            bunifuMetroTextbox6.Text = getrecord.SUPPLIER;
            bunifuMetroTextbox9.Text = getrecord.EXPIRY_DATE;
            comboBox1.SelectedText = getrecord.tcategory.catNAME;
        }
        private void bunifuFlatButton7_Click(object sender, EventArgs e)
        {
            var getrecords = (from c in ContextObject.context.tinventories.OfType<tinventory>()
                              where c.ITEM_CODE == cellSelected
                              select c).First();
            getrecords.ITEM_CODE = int.Parse(bunifuMetroTextbox2.Text);
            getrecords.ITEM_NAME = bunifuMetroTextbox3.Text;
            getrecords.ONSTOCK = bunifuMetroTextbox7.Text;
            getrecords.PURCHASE_PRICE = bunifuMetroTextbox4.Text;
            getrecords.SALES_PRICE = bunifuMetroTextbox5.Text;
            getrecords.SUPPLIER = bunifuMetroTextbox6.Text;
            getrecords.EXPIRY_DATE = bunifuMetroTextbox9.Text;


            ContextObject.context.SaveChanges();
            getInventory();
        }

        private void bunifuFlatButton6_Click(object sender, EventArgs e)
        {
            var getrecords = (from c in ContextObject.context.tinventories.OfType<tinventory>()
                              where c.ITEM_CODE == cellSelected
                              select c).First();
            ContextObject.context.tinventories.Remove(getrecords);
            ContextObject.context.SaveChanges();
            getInventory();
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            var getrecords = (from c in ContextObject.context.tinventories.OfType<tinventory>()
                              where c.ITEM_CODE == Convert.ToInt32(bunifuMetroTextbox1.Text) ||
                              c.ITEM_NAME == bunifuMetroTextbox1.Text ||
                               c.tcategory.catNAME == bunifuMetroTextbox1.Text ||
                               c.SUPPLIER == bunifuMetroTextbox1.Text ||
                              c.ITEM_NAME.Contains(bunifuMetroTextbox1.Text) ||
                              c.tcategory.catNAME.Contains(bunifuMetroTextbox1.Text) ||
                              c.SUPPLIER.Contains(bunifuMetroTextbox1.Text) 
                              
                              select c).ToList();

            bunifuCustomDataGrid1.DataSource = getrecords;
        }

        private void itemListForm_Load(object sender, EventArgs e)
        {
            getInventory();
            getListCat = getCat();
            comboBox1.DataSource = getListCat;
            comboBox1.DisplayMember = "catNAME";
            comboBox1.ValueMember = "catID";
        }

        private void bunifuCustomDataGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void exitB_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void bunifuCustomDataGrid1_Paint(object sender, PaintEventArgs e)
        {
            foreach (DataGridViewColumn c in bunifuCustomDataGrid1.Columns)
            {
                c.HeaderText = c.HeaderText.Replace("_", " ");

            }
        }

        private void minB_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dateandtime = DateTime.Now;
            this.label2.Text = dateandtime.ToString("hh:mm:ss");
            this.label1.Text = dateandtime.ToString("MM-dd-yyy");
        }

        private void label1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            combovalue = comboBox1.SelectedValue.ToString();
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            Hide();
            using ( addCategoryForm ac= new addCategoryForm())
            { ac.ShowDialog(); }
            Show();
        }


    }
}