﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Validation;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pos_01
{
    public partial class salesRegisterForm : Form
    {
       

        public salesRegisterForm(String uname)
        {
            InitializeComponent();
          bunifuCustomLabel15.Text = uname;
        }

        private void exitB_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void minB_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        private static int cellSelected;


        void getInventory()
        {

            var getrecord = (from c in ContextObject.context.tinventories.OfType<tinventory>()
                             select new
                             {
                                 c.ITEM_CODE,
                                 c.ITEM_NAME,
                                 c.SALES_PRICE
                             }).ToList();

            bunifuCustomDataGrid1.DataSource = getrecord;

        }
      

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            itemcode=int.Parse(bunifuMetroTextbox7.Text);
           var getrecord = (from c in ContextObject.context.tinventories.OfType<tinventory>()
                            where c.ITEM_CODE==itemcode
                            select c).FirstOrDefault();
           
           int onstock= Convert.ToInt32(getrecord.ONSTOCK);
           int itemsleft = onstock - Convert.ToInt32(bunifuMetroTextbox10.Text);
           getrecord.ONSTOCK = Convert.ToString(itemsleft);
           try
           {
               ContextObject.context.SaveChanges();
           }
           catch (System.Data.Entity.Validation.DbEntityValidationException ex)
           {
               foreach (var validationErrors in ex.EntityValidationErrors)
               {
                   foreach (var validationError in validationErrors.ValidationErrors)
                   {
                       Console.WriteLine("Property: {0} throws Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                   }
               }
           }
           //ContextObject.context.SaveChanges();
           getInventory();



            String q = Convert.ToString(bunifuMetroTextbox10.Text);
            bunifuCustomDataGrid2.Rows.Add(new Object[] { bunifuMetroTextbox7.Text, bunifuMetroTextbox8.Text, bunifuMetroTextbox9.Text, q, bunifuMetroTextbox11.Text });

            bunifuMetroTextbox7.Text = "";
            bunifuMetroTextbox8.Text = "";
            bunifuMetroTextbox9.Text = "";
            bunifuMetroTextbox10.Text = "";
            bunifuMetroTextbox11.Text = "";

            
        }

     
       
        
   

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dateandtime = DateTime.Now;
            this.label2.Text = dateandtime.ToString("hh:mm:ss");
            this.label1.Text = dateandtime.ToString("MM-dd-yyy");
        }

        private void label1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

      

        private void bunifuMetroTextbox10_KeyUp(object sender, KeyEventArgs e)
        {
            bunifuMetroTextbox11.Text = Convert.ToString(double.Parse(bunifuMetroTextbox10.Text) * double.Parse(bunifuMetroTextbox9.Text));
        }


        private void salesRegisterForm_Load(object sender, EventArgs e)
        {
            clear();
            getInventory();
            lastno();
            
           
        }

        

        void lastno()
        {
            var getrecord = (from c in ContextObject.context.ttransactions.OfType<ttransaction>()
                            orderby c.TRANSACTION_NO
                            select c).ToList().Last();
            bunifuCustomLabel16.Text = Convert.ToString(getrecord.TRANSACTION_NO +1);

        }

        private void bunifuCustomDataGrid1_Paint(object sender, PaintEventArgs e)
        {
            foreach (DataGridViewColumn c in bunifuCustomDataGrid1.Columns)
            {
                c.HeaderText = c.HeaderText.Replace("_", " ");

            }
        }

      

        private void bunifuCustomDataGrid1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cellSelected = Convert.ToInt32(bunifuCustomDataGrid1.Rows[e.RowIndex].Cells[0].Value);
            var getrecords = (from c in ContextObject.context.tinventories.OfType<tinventory>()
                              where c.ITEM_CODE== cellSelected
                              select c).First();
            bunifuMetroTextbox7.Text = Convert.ToString(getrecords.ITEM_CODE);
            bunifuMetroTextbox8.Text = getrecords.ITEM_NAME;
            bunifuMetroTextbox9.Text = Convert.ToString(getrecords.SALES_PRICE);
            bunifuMetroTextbox1.Text = "";
            
        }

        void tabletotal()
        {
            double sum = 0;
            for (int i = 0; i < bunifuCustomDataGrid2.Rows.Count; ++i)
            {
                sum += Convert.ToDouble(bunifuCustomDataGrid2.Rows[i].Cells[4].Value);
            }
            bunifuMetroTextbox2.Text = sum.ToString();
        }

        private void bunifuCustomDataGrid2_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            tabletotal();  
        }

        private void bunifuMetroTextbox3_KeyUp(object sender, KeyEventArgs e)
        {

        }

        private void bunifuMetroTextbox4_KeyUp(object sender, KeyEventArgs e)
        {
            bunifuMetroTextbox5.Text = Convert.ToString(double.Parse(bunifuMetroTextbox4.Text) - double.Parse(bunifuMetroTextbox6.Text));
        }

      

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            itemcode= Convert.ToInt32(bunifuMetroTextbox7.Text);
           var getrecord = (from c in ContextObject.context.tinventories.OfType<tinventory>()
                             where c.ITEM_CODE ==itemcode
                             select c).First();

            int onstock = Convert.ToInt32(getrecord.ONSTOCK);
            int itemsleft = onstock + Convert.ToInt32(bunifuMetroTextbox10.Text);
            getrecord.ONSTOCK = Convert.ToString(itemsleft);
            try
            {
                ContextObject.context.SaveChanges();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException ex)
            {
                foreach (var validationErrors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        Console.WriteLine("Property: {0} throws Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
            }
            //ContextObject.context.SaveChanges();
            getInventory();
            
            bunifuCustomDataGrid2.Rows.RemoveAt(bunifuCustomDataGrid2.CurrentCell.RowIndex);
            bunifuMetroTextbox7.Text = "";

            bunifuMetroTextbox8.Text = "";

            bunifuMetroTextbox9.Text ="";

            bunifuMetroTextbox10.Text = "";

            bunifuMetroTextbox11.Text = "";

        }

        private void bunifuCustomDataGrid2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
                        }

        private void bunifuCustomDataGrid2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {

                DataGridViewRow row = this.bunifuCustomDataGrid2.Rows[e.RowIndex];



                bunifuMetroTextbox7.Text = row.Cells[0].Value.ToString();

                bunifuMetroTextbox8.Text = row.Cells[1].Value.ToString();

                bunifuMetroTextbox9.Text = row.Cells[2].Value.ToString();

                bunifuMetroTextbox10.Text = row.Cells[3].Value.ToString();

                bunifuMetroTextbox11.Text = row.Cells[4].Value.ToString();


        }
        }

        private void bunifuCustomDataGrid2_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            tabletotal();
        }

        void clear(){
            bunifuCustomDataGrid2.Rows.Clear();
            bunifuCustomDataGrid2.Refresh();
            bunifuMetroTextbox7.Text = "";

            bunifuMetroTextbox8.Text = "";

            bunifuMetroTextbox9.Text = "";

            bunifuMetroTextbox10.Text = "";

            bunifuMetroTextbox11.Text = "";
            bunifuMetroTextbox2.Text = "";

            bunifuMetroTextbox3.Text = "";

            bunifuMetroTextbox4.Text = "";

            bunifuMetroTextbox5.Text = "";

            bunifuMetroTextbox6.Text = "";


    }
        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            clear();

        }

        private void bunifuMetroTextbox1_OnValueChanged(object sender, EventArgs e)
        {
            var getrecords = (from c in ContextObject.context.tinventories.OfType<tinventory>()
                              where
                              c.ITEM_NAME == bunifuMetroTextbox1.Text ||
                               c.tcategory.catNAME == bunifuMetroTextbox1.Text ||
                               c.SUPPLIER == bunifuMetroTextbox1.Text ||
                              c.ITEM_NAME.Contains(bunifuMetroTextbox1.Text) ||
                              c.tcategory.catNAME.Contains(bunifuMetroTextbox1.Text) ||
                              c.SUPPLIER.Contains(bunifuMetroTextbox1.Text)

                              select new
                             {
                                 c.ITEM_CODE,
                                 c.ITEM_NAME,
                                 c.SALES_PRICE
                             }).ToList();

            bunifuCustomDataGrid1.DataSource = getrecords;
        }

       


        void savetransaction()
        {
            empid = Convert.ToInt32(bunifuCustomLabel15.Text);
            ttransaction add = new ttransaction();
            var getemp = (from c in ContextObject.context.temployees.OfType<temployee>()
                            where c.empID == empid
                            select c).FirstOrDefault();
           
            add.temployee = new temployee();
            if (getemp != null)
            {
                add.temployee = getemp;

                add.temployee.empID = empid;
            }
           
            add.temployee.empID = empid;
            add.TRANSACTION_DATE = label1.Text;
            add.TOTAL = bunifuMetroTextbox2.Text;
            add.DISCOUNT = bunifuMetroTextbox3.Text;
            add.TOTAL_PAYABLE = bunifuMetroTextbox6.Text;
            add.AMOUNT_PAID = bunifuMetroTextbox4.Text;
            add.CHANGE = bunifuMetroTextbox5.Text;

            ContextObject.context.ttransactions.Add(add);
            try
            {
                ContextObject.context.SaveChanges();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException ex)
            {
                foreach (var validationErrors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        Console.WriteLine("Property: {0} throws Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
            }


           saveproducts();
        }

        

        void saveproducts()
        {

            
            transno = Convert.ToInt32(bunifuCustomLabel16.Text);
            for (int i = 0; i < bunifuCustomDataGrid2.Rows.Count; ++i)
            {
               
                itemcode = Convert.ToInt32(bunifuCustomDataGrid2.Rows[i].Cells[0].Value);
                var gettrans = (from c in ContextObject.context.ttransactions.OfType<ttransaction>()
                                where c.TRANSACTION_NO == transno
                                select c).FirstOrDefault();

                tproductbought add = new tproductbought();
                add.ttransaction=new ttransaction();
                if(gettrans != null){
                    add.ttransaction = gettrans;

                    add.ttransaction.TRANSACTION_NO = transno ;
                }
                add.QUANTITY = Convert.ToString(bunifuCustomDataGrid2.Rows[i].Cells[3].Value);
                add.PRICE = Convert.ToString(bunifuCustomDataGrid2.Rows[i].Cells[4].Value);
                add.tinventory = new tinventory();
 
                var getitem =(from c in ContextObject.context.tinventories.OfType<tinventory>()
                               where c.ITEM_CODE == itemcode
                                select c).FirstOrDefault();
                if (getitem != null)
                {
                    add.tinventory = getitem;

                    add.tinventory.ITEM_CODE = itemcode;
                }             

                ContextObject.context.tproductboughts.Add(add);
               
                try
                {
                    ContextObject.context.SaveChanges();
                }
                catch (System.Data.Entity.Validation.DbEntityValidationException ex)
                {
                    foreach (var validationErrors in ex.EntityValidationErrors)
                    {
                        foreach (var validationError in validationErrors.ValidationErrors)
                        {
                            Console.WriteLine("Property: {0} throws Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                        }
                    }
                }
               
            }
        }
            
 

        public static int empid;
        public static int itemcode;
        public static int transno;

        

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            
            savetransaction();
            
            Hide();
            using (paymentForm pf = new paymentForm(bunifuCustomLabel16.Text, bunifuMetroTextbox2.Text, bunifuMetroTextbox3.Text, bunifuMetroTextbox6.Text, bunifuMetroTextbox4.Text, bunifuMetroTextbox5.Text, label1.Text, label2.Text))
            { pf.ShowDialog();
            clear();
            lastno();
            }
            Show();

        }

        private void bunifuMetroTextbox4_OnValueChanged(object sender, EventArgs e)
        {
            double parsedValue;
            if (!double.TryParse(bunifuMetroTextbox4.Text, out parsedValue))
            {
                bunifuMetroTextbox4.Text = "";
                bunifuMetroTextbox5.Text = "0";
            }
            else
            {
                if (bunifuCustomDataGrid2.Rows.Count != 0)
                {
                    if (bunifuMetroTextbox4.Text != "")
                        bunifuMetroTextbox5.Text = (Convert.ToDouble(bunifuMetroTextbox4.Text) - Convert.ToDouble(bunifuMetroTextbox6.Text)).ToString();

                    if (Convert.ToDouble(bunifuMetroTextbox4.Text) >= Convert.ToDouble(bunifuMetroTextbox2.Text))
                    {
                        bunifuFlatButton3.Enabled = true;
                    }
                    else
                    {
                        bunifuFlatButton3.Enabled = false;
                    }
                }
                else
                {
                    bunifuMetroTextbox5.Text = "0";
                }
            }
        }

        private void bunifuMetroTextbox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            decimal x;
            if (ch == (char)Keys.Back)
            {
                e.Handled = false;
            }
            else if (!char.IsDigit(ch) && ch != '.' || !Decimal.TryParse(bunifuMetroTextbox4.Text + ch, out x))
            {
                e.Handled = true;
            }
        }

        private void bunifuMetroTextbox10_OnValueChanged(object sender, EventArgs e)
        {
            double parsedValue;
            if (!double.TryParse(bunifuMetroTextbox10.Text, out parsedValue))
            {
                bunifuMetroTextbox10.Text = "";
                bunifuMetroTextbox11.Text = "0";
            }
            else
            {
                if (Convert.ToDouble(bunifuMetroTextbox9.Text) != 0)
                {
                    if (bunifuMetroTextbox10.Text != "")
                        bunifuMetroTextbox11.Text = (Convert.ToDouble(bunifuMetroTextbox10.Text) * Convert.ToDouble(bunifuMetroTextbox9.Text)).ToString();

   
                }
                else
                {
                    bunifuMetroTextbox11.Text = "0";
                }
            }

        }

        private double discount()
        {
            double discount= Convert.ToDouble(bunifuMetroTextbox3.Text) / 100;
            double discountprice = discount * double.Parse(bunifuMetroTextbox2.Text);
            double finalprice = double.Parse(bunifuMetroTextbox2.Text)-discountprice;
            return finalprice;
        }

        private void bunifuMetroTextbox3_OnValueChanged(object sender, EventArgs e)
        {
            double parsedValue;
            if (!double.TryParse(bunifuMetroTextbox3.Text, out parsedValue))
            {
                bunifuMetroTextbox3.Text = "";
                bunifuMetroTextbox6.Text = "0";
            }
            else
            {
                if (bunifuCustomDataGrid2.Rows.Count != 0)
                {
                    if (bunifuMetroTextbox3.Text != "")
                        
                       
                        bunifuMetroTextbox6.Text = Convert.ToString(discount());


                }
                else
                {
                    bunifuMetroTextbox11.Text = "0";
                }
            }

        }

       
       

       

       
      

       
      

     

        
   
                   
        
     

        }

        

     

       

       


    }
