﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pos_01
{
    class ContextObject
    {

        public static nfneEntities2 context = new nfneEntities2();
    }
}
