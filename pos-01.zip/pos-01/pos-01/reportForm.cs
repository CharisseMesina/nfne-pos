﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pos_01
{
    public partial class reportForm : Form
    {
        public reportForm(string uname)
        {
            InitializeComponent();
            bunifuCustomLabel1.Text = uname;
        }

        private void exitB_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void minB_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dateandtime = DateTime.Now;
            this.label2.Text = dateandtime.ToString("hh:mm:ss");
            this.label1.Text = dateandtime.ToString("MM-dd-yyy");
        }

        private void label1_Click(object sender, EventArgs e)
        {

            timer1.Start();
        }

        private void loginB_Click(object sender, EventArgs e)
        {
            Hide();
            using (salesReportForm sr = new salesReportForm())
            { sr.ShowDialog(); }
            Show();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            Hide();
            using (receiptForm rf = new receiptForm())
            { rf.ShowDialog(); }
            Show();
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            Hide();
            using (salesReportForm sr = new salesReportForm())
            { sr.ShowDialog(); }
            Show();
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {

        }
    }
}
